export interface UserFromJwt {
  user: string;
  email: string;
  name: string;
}
