export interface UserFromJwt {
  _id: string;
  user: string;
  name: string;
}
