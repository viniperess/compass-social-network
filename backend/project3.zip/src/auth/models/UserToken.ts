export interface UserToken {
  access_token: string;
}
