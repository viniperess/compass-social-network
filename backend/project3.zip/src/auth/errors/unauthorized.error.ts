export class UnauthorizedError extends Error {}
