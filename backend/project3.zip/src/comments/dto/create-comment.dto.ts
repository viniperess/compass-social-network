export class CreateCommentDto {
  id: string;
  user: string;
  comment: string;
}
