export class UpdateCommentDto {
  comment?: string;
}
