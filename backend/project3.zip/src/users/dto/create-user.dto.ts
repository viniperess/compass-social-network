export class CreateUserDto {
  _id: string;
  name: string;
  user: string;
  birthdate: string;
  email: string;
  password: string;
  profile_photo: string;
}
